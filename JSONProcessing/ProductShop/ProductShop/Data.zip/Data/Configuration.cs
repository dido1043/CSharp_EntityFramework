﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-DFE3FV0;Database=ProductShop;Integrated Security=True; TrustServerCertificate=True;";
    }
}
